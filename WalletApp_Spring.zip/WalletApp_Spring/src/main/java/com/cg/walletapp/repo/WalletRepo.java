package com.cg.walletapp.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.walletapp.beans.Customer;

@Repository("walletrepo")
public interface WalletRepo extends CrudRepository<Customer, String> {

}
