package com.cg.walletapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalletSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalletSpringApplication.class, args);
	}
}
